import { useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from '../lib/AuthContext';
import { useRealtimeTable } from '../lib/useRealtimeTable';
import { useSaveStatus } from '../lib/useSaveStatus';
import SaveStatus from './SaveStatus';

const empty = {
  business_name: '', contact_person: '', call_date: '', call_time: '',
  outcome: '', next_follow_up: '', notes: '',
};

export default function CallsPanel({ showAll = false, salesRepNames = {} }) {
  const { session, profile } = useAuth();
  const { rows, loading } = useRealtimeTable('calls');
  const [form, setForm] = useState(empty);
  const { status, errorMessage, run } = useSaveStatus();
  const canCreate = profile?.role === 'sales_rep';

  const submit = async (e) => {
    e.preventDefault();
    const ok = await run(() =>
      supabase.from('calls').insert({ ...form, created_by: session.user.id })
    );
    if (ok) setForm(empty);
  };

  return (
    <div className="panel">
      {canCreate && (
        <form onSubmit={submit} className="record-form">
          <h3>Log Call</h3>
          <div className="grid-2">
            <label>Business<input required value={form.business_name} onChange={(e) => setForm({ ...form, business_name: e.target.value })} /></label>
            <label>Contact<input value={form.contact_person} onChange={(e) => setForm({ ...form, contact_person: e.target.value })} /></label>
            <label>Date<input type="date" value={form.call_date} onChange={(e) => setForm({ ...form, call_date: e.target.value })} /></label>
            <label>Time<input type="time" value={form.call_time} onChange={(e) => setForm({ ...form, call_time: e.target.value })} /></label>
            <label>Outcome<input value={form.outcome} onChange={(e) => setForm({ ...form, outcome: e.target.value })} /></label>
            <label>Next follow-up<input type="date" value={form.next_follow_up} onChange={(e) => setForm({ ...form, next_follow_up: e.target.value })} /></label>
          </div>
          <label>Notes<textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></label>
          <div className="form-actions">
            <button type="submit" disabled={status === 'saving'}>Log Call</button>
            <SaveStatus status={status} errorMessage={errorMessage} />
          </div>
        </form>
      )}
      <h3>{showAll ? 'All Calls' : 'My Calls'}</h3>
      {loading ? <p className="muted">Loading…</p> : rows.length === 0 ? <p className="muted">No calls logged yet.</p> : (
        <table className="data-table">
          <thead><tr><th>Business</th><th>Contact</th><th>Date</th><th>Outcome</th>{showAll && <th>Sales Rep</th>}</tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.business_name}</td><td>{r.contact_person}</td>
                <td>{r.call_date} {r.call_time}</td><td>{r.outcome}</td>
                {showAll && <td>{salesRepNames[r.created_by] || '—'}</td>}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
