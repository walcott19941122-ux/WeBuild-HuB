import { useEffect, useRef, useState, useCallback } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from '../lib/AuthContext';
import { useSaveStatus } from '../lib/useSaveStatus';
import SaveStatus from './SaveStatus';

// otherUserId: for admin view, the worker/rep whose thread is being read.
// For a worker/rep's own view, pass null — it resolves to their own thread.
export default function MessageThread({ otherUserId = null, otherUserName = '' }) {
  const { session, profile } = useAuth();
  const [threadId, setThreadId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [body, setBody] = useState('');
  const [loading, setLoading] = useState(true);
  const { status, errorMessage, run } = useSaveStatus();
  const bottomRef = useRef(null);
  const isAdmin = profile?.role === 'admin';
  const targetUserId = isAdmin ? otherUserId : session?.user?.id;

  const loadThread = useCallback(async () => {
    if (!targetUserId) { setLoading(false); return; }
    setLoading(true);

    let { data: thread } = await supabase
      .from('message_threads')
      .select('id')
      .eq('user_id', targetUserId)
      .maybeSingle();

    if (!thread) {
      const { data: created, error } = await supabase
        .from('message_threads')
        .insert({ user_id: targetUserId })
        .select('id')
        .single();
      if (error) { setLoading(false); return; }
      thread = created;
    }
    setThreadId(thread.id);

    const { data: msgs } = await supabase
      .from('messages')
      .select('*')
      .eq('thread_id', thread.id)
      .order('created_at', { ascending: true });
    setMessages(msgs || []);
    setLoading(false);

    // mark incoming messages as read
    const unreadFromOther = (msgs || []).filter(
      (m) => m.sender_id !== session?.user?.id && !m.read_at
    );
    if (unreadFromOther.length) {
      await supabase
        .from('messages')
        .update({ read_at: new Date().toISOString() })
        .in('id', unreadFromOther.map((m) => m.id));
    }
  }, [targetUserId, session?.user?.id]);

  useEffect(() => { loadThread(); }, [loadThread]);

  useEffect(() => {
    if (!threadId) return;
    const channel = supabase
      .channel(`messages-thread-${threadId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `thread_id=eq.${threadId}` },
        (payload) => {
          setMessages((prev) => (prev.some((m) => m.id === payload.new.id) ? prev : [...prev, payload.new]));
        }
      )
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, [threadId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const send = async (e) => {
    e.preventDefault();
    if (!body.trim() || !threadId) return;
    const text = body.trim();
    const ok = await run(() =>
      supabase.from('messages').insert({
        thread_id: threadId,
        sender_id: session.user.id,
        sender_role: profile.role,
        body: text,
      })
    );
    if (ok) setBody('');
  };

  if (isAdmin && !otherUserId) {
    return <p className="muted">Select a worker or sales rep to view their messages.</p>;
  }

  return (
    <div className="message-thread">
      {otherUserName && <h3>Messages with {otherUserName}</h3>}
      <div className="message-list">
        {loading && <p className="muted">Loading…</p>}
        {!loading && messages.length === 0 && <p className="muted">No messages yet.</p>}
        {messages.map((m) => (
          <div key={m.id} className={`message-bubble ${m.sender_id === session?.user?.id ? 'mine' : 'theirs'}`}>
            <div className="message-meta">
              {m.sender_role === 'admin' ? 'Admin' : (m.sender_id === session?.user?.id ? 'You' : otherUserName)}
              {' · '}
              {new Date(m.created_at).toLocaleString()}
            </div>
            <div className="message-body">{m.body}</div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <form onSubmit={send} className="message-form">
        <input
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Type a message…"
        />
        <button type="submit" disabled={status === 'saving' || !body.trim()}>Send</button>
        <SaveStatus status={status} errorMessage={errorMessage} />
      </form>
    </div>
  );
}
