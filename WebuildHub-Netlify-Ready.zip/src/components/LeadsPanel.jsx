import { useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from '../lib/AuthContext';
import { useRealtimeTable } from '../lib/useRealtimeTable';
import { useSaveStatus } from '../lib/useSaveStatus';
import SaveStatus from './SaveStatus';

const empty = {
  business_name: '', country: '', contact_person: '', phone: '', email: '',
  website: '', service_interested: '', date_contacted: '', next_follow_up: '',
  status: 'new', notes: '',
};

export default function LeadsPanel({ showAll = false, salesRepNames = {} }) {
  const { session, profile } = useAuth();
  const { rows, loading } = useRealtimeTable('leads');
  const [form, setForm] = useState(empty);
  const { status, errorMessage, run } = useSaveStatus();

  const canCreate = profile?.role === 'sales_rep';

  const submit = async (e) => {
    e.preventDefault();
    const ok = await run(() =>
      supabase.from('leads').insert({ ...form, created_by: session.user.id })
    );
    if (ok) setForm(empty);
  };

  return (
    <div className="panel">
      {canCreate && (
        <form onSubmit={submit} className="record-form">
          <h3>Add Lead</h3>
          <div className="grid-2">
            <label>Business name<input required value={form.business_name} onChange={(e) => setForm({ ...form, business_name: e.target.value })} /></label>
            <label>Country<input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></label>
            <label>Contact person<input value={form.contact_person} onChange={(e) => setForm({ ...form, contact_person: e.target.value })} /></label>
            <label>Phone<input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></label>
            <label>Email<input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label>
            <label>Website<input value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} /></label>
            <label>Service interested in<input value={form.service_interested} onChange={(e) => setForm({ ...form, service_interested: e.target.value })} /></label>
            <label>Status
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                <option value="new">New</option>
                <option value="contacted">Contacted</option>
                <option value="qualified">Qualified</option>
                <option value="won">Won</option>
                <option value="lost">Lost</option>
              </select>
            </label>
            <label>Date contacted<input type="date" value={form.date_contacted} onChange={(e) => setForm({ ...form, date_contacted: e.target.value })} /></label>
            <label>Next follow-up<input type="date" value={form.next_follow_up} onChange={(e) => setForm({ ...form, next_follow_up: e.target.value })} /></label>
          </div>
          <label>Notes<textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></label>
          <div className="form-actions">
            <button type="submit" disabled={status === 'saving'}>Add Lead</button>
            <SaveStatus status={status} errorMessage={errorMessage} />
          </div>
        </form>
      )}

      <h3>{showAll ? 'All Leads' : 'My Leads'}</h3>
      {loading ? <p className="muted">Loading…</p> : rows.length === 0 ? <p className="muted">No leads yet.</p> : (
        <table className="data-table">
          <thead><tr><th>Business</th><th>Country</th><th>Contact</th><th>Status</th><th>Follow-up</th>{showAll && <th>Sales Rep</th>}<th>Created</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.business_name}</td><td>{r.country}</td><td>{r.contact_person}</td>
                <td><span className={`badge status-${r.status}`}>{r.status}</span></td>
                <td>{r.next_follow_up || '—'}</td>
                {showAll && <td>{salesRepNames[r.created_by] || '—'}</td>}
                <td>{new Date(r.created_at).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
