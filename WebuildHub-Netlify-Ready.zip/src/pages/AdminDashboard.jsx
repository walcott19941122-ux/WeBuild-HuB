import { useEffect, useMemo, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from '../lib/AuthContext';
import MessageThread from '../components/MessageThread';
import LeadsPanel from '../components/LeadsPanel';
import CallsPanel from '../components/CallsPanel';
import AppointmentsPanel from '../components/AppointmentsPanel';
import ReportsPanel from '../components/ReportsPanel';
import QualifiedLeadsPanel from '../components/QualifiedLeadsPanel';
import NotificationsPanel from '../components/NotificationsPanel';
import ApplicationsPanel from '../components/ApplicationsPanel';
import TasksPanel from '../components/TasksPanel';

const TABS = ['Notifications', 'Messages', 'Applications', 'Leads', 'Calls', 'Appointments', 'Reports', 'Qualified Leads', 'Tasks', 'Team'];

export default function AdminDashboard() {
  const { profile, signOut } = useAuth();
  const [tab, setTab] = useState('Notifications');
  const [team, setTeam] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    supabase.from('profiles').select('*').in('role', ['worker', 'sales_rep']).eq('status', 'approved')
      .then(({ data }) => setTeam(data || []));
  }, []);

  const nameById = useMemo(() => Object.fromEntries(team.map((u) => [u.id, u.full_name])), [team]);
  const salesReps = team.filter((u) => u.role === 'sales_rep');

  return (
    <div className="dashboard">
      <header className="dash-header">
        <h1>weBUILD Business Hub — Admin</h1>
        <div className="header-right">
          <span>{profile?.full_name}</span>
          <button className="link-btn" onClick={signOut}>Log out</button>
        </div>
      </header>
      <nav className="tabs">
        {TABS.map((t) => <button key={t} className={tab === t ? 'active' : ''} onClick={() => setTab(t)}>{t}</button>)}
      </nav>
      <main className="dash-main">
        {tab === 'Notifications' && <NotificationsPanel />}
        {tab === 'Applications' && <ApplicationsPanel />}
        {tab === 'Leads' && <LeadsPanel showAll salesRepNames={nameById} />}
        {tab === 'Calls' && <CallsPanel showAll salesRepNames={nameById} />}
        {tab === 'Appointments' && <AppointmentsPanel showAll salesRepNames={nameById} />}
        {tab === 'Reports' && <ReportsPanel showAll salesRepNames={nameById} />}
        {tab === 'Qualified Leads' && <QualifiedLeadsPanel isAdmin salesRepNames={nameById} />}
        {tab === 'Tasks' && <TasksPanel isAdmin assignableUsers={team} />}
        {tab === 'Team' && (
          <div className="panel">
            <h3>Workers &amp; Sales Reps</h3>
            <table className="data-table">
              <thead><tr><th>Name</th><th>Role</th><th>Phone</th></tr></thead>
              <tbody>
                {team.map((u) => <tr key={u.id}><td>{u.full_name}</td><td>{u.role}</td><td>{u.phone}</td></tr>)}
              </tbody>
            </table>
          </div>
        )}
        {tab === 'Messages' && (
          <div className="messages-layout">
            <ul className="thread-list">
              {team.map((u) => (
                <li key={u.id} className={selectedUser === u.id ? 'active' : ''} onClick={() => setSelectedUser(u.id)}>
                  {u.full_name} <span className="muted small">{u.role}</span>
                </li>
              ))}
              {team.length === 0 && <li className="muted">No approved workers or sales reps yet.</li>}
            </ul>
            <div className="thread-view">
              <MessageThread otherUserId={selectedUser} otherUserName={nameById[selectedUser] || ''} />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
