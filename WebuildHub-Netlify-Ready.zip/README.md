# weBUILD Business Hub

Rebuilt with a real backend so submissions actually reach Admin, sync across
devices, and never show "Saved" unless the data really saved.

Stack: **React (Vite)** for the frontend + **Supabase** (Postgres + Auth +
Realtime) for the backend. No custom server to run — Supabase is the database.

## 1. Create your Supabase project

1. Go to https://supabase.com → New project (free tier is fine).
2. Once it's created, go to **SQL Editor → New query**, paste the entire
   contents of `supabase-schema.sql` from this folder, and click **Run**.
   This creates every table (Users/profiles, Messages, Leads, Calls,
   Appointments, Reports, Qualified Leads, Applications, Tasks,
   Notifications), the row-level security rules (so a worker can only ever
   see their own data, admin sees everything), and the triggers that fire
   an admin notification the moment something new comes in.
3. Go to **Project Settings → API**. Copy the **Project URL** and the
   **anon public** key — you'll need both in step 3.

## 2. Create the first Admin account

Supabase Auth doesn't let you sign up as "admin" through the app (on
purpose — anyone could otherwise self-promote). To create the first admin:

1. In Supabase: **Authentication → Users → Add user** → enter your email
   and a password, and check "Auto Confirm User".
2. Copy the new user's UUID from that same screen.
3. Go to **SQL Editor** and run (replace both placeholders):
   ```sql
   insert into profiles (id, full_name, role, status)
   values ('PASTE-USER-UUID-HERE', 'Your Name', 'admin', 'approved');
   ```
4. You can now log in to the app with that email/password as Admin.

Workers and Sales Reps, by contrast, use the **"Apply for account"** tab
inside the app itself — their application lands on the Admin's
**Applications** tab, and they can log in the moment Admin clicks Approve.

## 3. Run it locally (optional, to test before deploying)

```bash
cp .env.example .env
# edit .env and paste your Project URL + anon key
npm install
npm run dev
```

## 4. Deploy to Netlify

1. Push this folder to a GitHub repo (Netlify deploys from Git, so a real
   repo — not a drag-and-drop zip — is what lets you keep shipping fixes).
2. In Netlify: **Add new site → Import an existing project** → pick the repo.
3. Build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. **Site settings → Environment variables** → add:
   - `VITE_SUPABASE_URL` = your Project URL
   - `VITE_SUPABASE_ANON_KEY` = your anon public key
5. Deploy.

That's it — no separate backend to host. Supabase *is* the shared,
persistent, cross-device database; Netlify just serves the static frontend.

## What changed vs. the old version

- **No localStorage / sessionStorage / browser-only state anywhere** for
  messages, leads, calls, appointments, reports, tasks, or applications —
  everything writes straight to Postgres via Supabase.
- **Real save confirmation.** Every Save/Send/Submit button goes
  `Saving…` → `Saved ✓` only after the database confirms the write, or
  `Unable to save. Please try again.` if it fails. See
  `src/lib/useSaveStatus.js` — every form in the app uses this one hook, so
  the behavior is consistent everywhere.
- **Live sync, not fake sync.** `src/lib/useRealtimeTable.js` subscribes to
  Postgres changes via Supabase Realtime, so when a Sales Rep adds a lead,
  it appears on Admin's screen without Admin refreshing. Messages work the
  same way in `MessageThread.jsx`.
- **Row-level security enforces ownership at the database, not just the UI**
  — a worker's Supabase session literally cannot query another worker's
  messages, tasks, or notes, even if someone tried to hit the API directly.
- **Admin notifications** are generated server-side by Postgres triggers
  (new lead, new qualified lead, new call, new appointment, new report, new
  application, new message) — they show up in the Notifications tab and
  don't depend on any client staying open.
- **Applications require Admin approval** before a Worker/Sales Rep account
  can log in — enforced by the `profiles.status` check on login, not just
  hidden UI.

## Testing the cross-device scenarios from the spec

Once deployed, this exact flow will work as described:

1. Admin logs in on Computer A.
2. Worker logs in on Phone B, applies (if new) → Admin approves from
   Applications tab → Worker can now log in.
3. Worker sends a message → Admin sees it appear live (or after refresh)
   in the Messages tab, with the worker's name pre-selected from the list.
4. Admin replies → Worker sees the reply live, or after refreshing Phone B.
5. Same pattern for leads, calls, appointments, reports, and tasks — each
   write goes to Postgres immediately and is readable by anyone whose RLS
   policy allows it, from any device, any time.
