import { useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import MessageThread from '../components/MessageThread';
import TasksPanel from '../components/TasksPanel';

const TABS = ['Messages with Admin', 'My Tasks'];

export default function WorkerDashboard() {
  const { profile, signOut } = useAuth();
  const [tab, setTab] = useState('Messages with Admin');

  return (
    <div className="dashboard">
      <header className="dash-header">
        <h1>weBUILD Business Hub — Worker</h1>
        <div className="header-right">
          <span>{profile?.full_name}</span>
          <button className="link-btn" onClick={signOut}>Log out</button>
        </div>
      </header>
      <nav className="tabs">
        {TABS.map((t) => <button key={t} className={tab === t ? 'active' : ''} onClick={() => setTab(t)}>{t}</button>)}
      </nav>
      <main className="dash-main">
        {tab === 'Messages with Admin' && (
          <div className="panel">
            <MessageThread otherUserName="Admin" />
          </div>
        )}
        {tab === 'My Tasks' && <TasksPanel />}
      </main>
    </div>
  );
}
