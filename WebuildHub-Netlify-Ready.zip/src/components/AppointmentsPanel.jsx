import { useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from '../lib/AuthContext';
import { useRealtimeTable } from '../lib/useRealtimeTable';
import { useSaveStatus } from '../lib/useSaveStatus';
import SaveStatus from './SaveStatus';

const empty = { business_name: '', contact_person: '', appt_date: '', appt_time: '', meeting_type: '', notes: '' };

export default function AppointmentsPanel({ showAll = false, salesRepNames = {} }) {
  const { session, profile } = useAuth();
  const { rows, loading } = useRealtimeTable('appointments');
  const [form, setForm] = useState(empty);
  const { status, errorMessage, run } = useSaveStatus();
  const canCreate = profile?.role === 'sales_rep';

  const submit = async (e) => {
    e.preventDefault();
    const ok = await run(() =>
      supabase.from('appointments').insert({ ...form, created_by: session.user.id })
    );
    if (ok) setForm(empty);
  };

  return (
    <div className="panel">
      {canCreate && (
        <form onSubmit={submit} className="record-form">
          <h3>Add Appointment</h3>
          <div className="grid-2">
            <label>Business<input required value={form.business_name} onChange={(e) => setForm({ ...form, business_name: e.target.value })} /></label>
            <label>Contact<input value={form.contact_person} onChange={(e) => setForm({ ...form, contact_person: e.target.value })} /></label>
            <label>Date<input type="date" required value={form.appt_date} onChange={(e) => setForm({ ...form, appt_date: e.target.value })} /></label>
            <label>Time<input type="time" value={form.appt_time} onChange={(e) => setForm({ ...form, appt_time: e.target.value })} /></label>
            <label>Meeting type<input value={form.meeting_type} onChange={(e) => setForm({ ...form, meeting_type: e.target.value })} placeholder="Site visit, call, video…" /></label>
          </div>
          <label>Notes<textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></label>
          <div className="form-actions">
            <button type="submit" disabled={status === 'saving'}>Add Appointment</button>
            <SaveStatus status={status} errorMessage={errorMessage} />
          </div>
        </form>
      )}
      <h3>{showAll ? 'All Appointments' : 'My Appointments'}</h3>
      {loading ? <p className="muted">Loading…</p> : rows.length === 0 ? <p className="muted">No appointments yet.</p> : (
        <table className="data-table">
          <thead><tr><th>Business</th><th>Contact</th><th>Date</th><th>Type</th>{showAll && <th>Sales Rep</th>}</tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.business_name}</td><td>{r.contact_person}</td>
                <td>{r.appt_date} {r.appt_time}</td><td>{r.meeting_type}</td>
                {showAll && <td>{salesRepNames[r.created_by] || '—'}</td>}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
