import { useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useRealtimeTable } from '../lib/useRealtimeTable';

export default function ApplicationsPanel() {
  const { rows, loading } = useRealtimeTable('applications');
  const [busyId, setBusyId] = useState(null);

  const decide = async (app, decision) => {
    setBusyId(app.id);
    // Update both the application record and the profile's status so
    // login is unlocked (or blocked) the moment the admin decides.
    await supabase.from('applications').update({ status: decision }).eq('id', app.id);
    await supabase.from('profiles').update({ status: decision }).eq('id', app.user_id);
    setBusyId(null);
  };

  const pending = rows.filter((r) => r.status === 'pending');
  const decided = rows.filter((r) => r.status !== 'pending');

  return (
    <div className="panel">
      <h3>Pending Applications {pending.length > 0 && <span className="unread-count">{pending.length}</span>}</h3>
      {loading ? <p className="muted">Loading…</p> : pending.length === 0 ? <p className="muted">No pending applications.</p> : (
        <table className="data-table">
          <thead><tr><th>Name</th><th>Role</th><th>Phone</th><th>Applied</th><th></th></tr></thead>
          <tbody>
            {pending.map((a) => (
              <tr key={a.id}>
                <td>{a.full_name}</td><td>{a.requested_role}</td><td>{a.phone}</td>
                <td>{new Date(a.created_at).toLocaleString()}</td>
                <td className="row-actions">
                  <button className="link-btn" disabled={busyId === a.id} onClick={() => decide(a, 'approved')}>Approve</button>
                  <button className="link-btn danger" disabled={busyId === a.id} onClick={() => decide(a, 'rejected')}>Reject</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {decided.length > 0 && (
        <>
          <h3>Reviewed</h3>
          <table className="data-table">
            <thead><tr><th>Name</th><th>Role</th><th>Status</th></tr></thead>
            <tbody>
              {decided.map((a) => (
                <tr key={a.id}><td>{a.full_name}</td><td>{a.requested_role}</td><td><span className={`badge status-${a.status}`}>{a.status}</span></td></tr>
              ))}
            </tbody>
          </table>
        </>
      )}
    </div>
  );
}
