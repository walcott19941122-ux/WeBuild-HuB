export default function SaveStatus({ status, errorMessage }) {
  if (status === 'idle') return null;
  if (status === 'saving') return <span className="save-status saving">Saving…</span>;
  if (status === 'saved') return <span className="save-status saved">Saved ✓</span>;
  if (status === 'error') return <span className="save-status error">{errorMessage || 'Unable to save. Please try again.'}</span>;
  return null;
}
