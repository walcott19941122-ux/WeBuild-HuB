import { useAuth } from './lib/AuthContext';
import AuthPage from './pages/AuthPage';
import PendingApproval from './pages/PendingApproval';
import AdminDashboard from './pages/AdminDashboard';
import WorkerDashboard from './pages/WorkerDashboard';
import SalesRepDashboard from './pages/SalesRepDashboard';

export default function App() {
  const { session, profile, loading } = useAuth();

  if (loading) return <div className="loading-screen">Loading…</div>;
  if (!session) return <AuthPage />;
  if (!profile) return <div className="loading-screen">Setting up your account…</div>;
  if (profile.status !== 'approved') return <PendingApproval status={profile.status} />;

  if (profile.role === 'admin') return <AdminDashboard />;
  if (profile.role === 'worker') return <WorkerDashboard />;
  if (profile.role === 'sales_rep') return <SalesRepDashboard />;

  return <div className="loading-screen">Unknown role — contact an admin.</div>;
}
