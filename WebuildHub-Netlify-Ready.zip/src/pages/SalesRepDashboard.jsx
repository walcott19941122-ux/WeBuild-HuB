import { useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import MessageThread from '../components/MessageThread';
import LeadsPanel from '../components/LeadsPanel';
import CallsPanel from '../components/CallsPanel';
import AppointmentsPanel from '../components/AppointmentsPanel';
import ReportsPanel from '../components/ReportsPanel';
import QualifiedLeadsPanel from '../components/QualifiedLeadsPanel';
import TasksPanel from '../components/TasksPanel';

const TABS = ['Messages with Admin', 'Leads', 'Calls', 'Appointments', 'Reports', 'Qualified Leads', 'My Tasks'];

export default function SalesRepDashboard() {
  const { profile, signOut } = useAuth();
  const [tab, setTab] = useState('Messages with Admin');

  return (
    <div className="dashboard">
      <header className="dash-header">
        <h1>weBUILD Business Hub — Sales</h1>
        <div className="header-right">
          <span>{profile?.full_name}</span>
          <button className="link-btn" onClick={signOut}>Log out</button>
        </div>
      </header>
      <nav className="tabs">
        {TABS.map((t) => <button key={t} className={tab === t ? 'active' : ''} onClick={() => setTab(t)}>{t}</button>)}
      </nav>
      <main className="dash-main">
        {tab === 'Messages with Admin' && (
          <div className="panel">
            <MessageThread otherUserName="Admin" />
          </div>
        )}
        {tab === 'Leads' && <LeadsPanel />}
        {tab === 'Calls' && <CallsPanel />}
        {tab === 'Appointments' && <AppointmentsPanel />}
        {tab === 'Reports' && <ReportsPanel />}
        {tab === 'Qualified Leads' && <QualifiedLeadsPanel />}
        {tab === 'My Tasks' && <TasksPanel />}
      </main>
    </div>
  );
}
