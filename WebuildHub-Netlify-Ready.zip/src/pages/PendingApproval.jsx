import { useAuth } from '../lib/AuthContext';

export default function PendingApproval({ status }) {
  const { signOut } = useAuth();
  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>weBUILD Business Hub</h1>
        {status === 'rejected' ? (
          <p>Your application was not approved. Contact your admin if you believe this is a mistake.</p>
        ) : (
          <p>Your application is awaiting admin approval. You'll be able to log in as soon as it's approved.</p>
        )}
        <button className="link-btn" onClick={signOut}>Log out</button>
      </div>
    </div>
  );
}
