-- ============================================================
-- weBUILD Business Hub — Database Schema (Supabase / Postgres)
-- ============================================================
-- Run this whole file once in Supabase: Dashboard → SQL Editor → New query → paste → Run
-- Safe to re-run: uses "if not exists" / "or replace" throughout.

create extension if not exists "pgcrypto";

-- ------------------------------------------------------------
-- PROFILES (one row per auth user — role + status live here)
-- ------------------------------------------------------------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null check (role in ('admin','worker','sales_rep')),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- APPLICATIONS (signup requests before a profile is approved)
-- ------------------------------------------------------------
create table if not exists applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  full_name text not null,
  requested_role text not null check (requested_role in ('worker','sales_rep')),
  phone text,
  notes text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- MESSAGE THREADS (one thread per non-admin user, admin is the counterpart)
-- ------------------------------------------------------------
create table if not exists message_threads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  unique(user_id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  thread_id uuid not null references message_threads(id) on delete cascade,
  sender_id uuid not null references auth.users(id),
  sender_role text not null check (sender_role in ('admin','worker','sales_rep')),
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- LEADS
-- ------------------------------------------------------------
create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  business_name text not null,
  country text,
  contact_person text,
  phone text,
  email text,
  website text,
  service_interested text,
  date_contacted date,
  next_follow_up date,
  status text not null default 'new',
  notes text,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- CALLS
-- ------------------------------------------------------------
create table if not exists calls (
  id uuid primary key default gen_random_uuid(),
  business_name text not null,
  contact_person text,
  call_date date not null default current_date,
  call_time time,
  outcome text,
  next_follow_up date,
  notes text,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- APPOINTMENTS
-- ------------------------------------------------------------
create table if not exists appointments (
  id uuid primary key default gen_random_uuid(),
  business_name text not null,
  contact_person text,
  appt_date date not null,
  appt_time time,
  meeting_type text,
  notes text,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- REPORTS (daily sales rep activity report)
-- ------------------------------------------------------------
create table if not exists reports (
  id uuid primary key default gen_random_uuid(),
  report_date date not null default current_date,
  calls_made int default 0,
  businesses_contacted int default 0,
  leads_generated int default 0,
  follow_ups int default 0,
  meetings int default 0,
  general_notes text,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- QUALIFIED LEADS
-- ------------------------------------------------------------
create table if not exists qualified_leads (
  id uuid primary key default gen_random_uuid(),
  business_name text not null,
  country text,
  service text,
  status text not null default 'unhandled' check (status in ('unhandled','handled')),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- TASKS (admin assigns to a worker or sales rep)
-- ------------------------------------------------------------
create table if not exists tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  assigned_to uuid not null references auth.users(id),
  assigned_by uuid not null references auth.users(id),
  status text not null default 'open' check (status in ('open','in_progress','done')),
  due_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- NOTIFICATIONS (admin-facing feed)
-- ------------------------------------------------------------
create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references auth.users(id),
  type text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- updated_at auto-touch trigger
-- ------------------------------------------------------------
create or replace function touch_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_profiles_touch on profiles;
create trigger trg_profiles_touch before update on profiles for each row execute function touch_updated_at();

drop trigger if exists trg_applications_touch on applications;
create trigger trg_applications_touch before update on applications for each row execute function touch_updated_at();

drop trigger if exists trg_leads_touch on leads;
create trigger trg_leads_touch before update on leads for each row execute function touch_updated_at();

drop trigger if exists trg_qualified_leads_touch on qualified_leads;
create trigger trg_qualified_leads_touch before update on qualified_leads for each row execute function touch_updated_at();

drop trigger if exists trg_tasks_touch on tasks;
create trigger trg_tasks_touch before update on tasks for each row execute function touch_updated_at();

-- ------------------------------------------------------------
-- Helper: is the current user an approved admin?
-- ------------------------------------------------------------
create or replace function is_admin() returns boolean as $$
  select exists (
    select 1 from profiles
    where id = auth.uid() and role = 'admin' and status = 'approved'
  );
$$ language sql stable security definer;

-- ------------------------------------------------------------
-- Row Level Security
-- ------------------------------------------------------------
alter table profiles enable row level security;
alter table applications enable row level security;
alter table message_threads enable row level security;
alter table messages enable row level security;
alter table leads enable row level security;
alter table calls enable row level security;
alter table appointments enable row level security;
alter table reports enable row level security;
alter table qualified_leads enable row level security;
alter table tasks enable row level security;
alter table notifications enable row level security;

-- profiles: everyone can read their own; admin reads/writes all
drop policy if exists profiles_self_select on profiles;
create policy profiles_self_select on profiles for select using (id = auth.uid() or is_admin());
drop policy if exists profiles_self_update on profiles;
create policy profiles_self_update on profiles for update using (id = auth.uid() or is_admin());
drop policy if exists profiles_admin_insert on profiles;
create policy profiles_admin_insert on profiles for insert with check (id = auth.uid() or is_admin());

-- applications: user creates their own, admin sees/updates all
drop policy if exists applications_insert on applications;
create policy applications_insert on applications for insert with check (user_id = auth.uid());
drop policy if exists applications_select on applications;
create policy applications_select on applications for select using (user_id = auth.uid() or is_admin());
drop policy if exists applications_update on applications;
create policy applications_update on applications for update using (is_admin());

-- message_threads: owner + admin
drop policy if exists threads_select on message_threads;
create policy threads_select on message_threads for select using (user_id = auth.uid() or is_admin());
drop policy if exists threads_insert on message_threads;
create policy threads_insert on message_threads for insert with check (user_id = auth.uid() or is_admin());

-- messages: readable/writable by the thread owner or admin
drop policy if exists messages_select on messages;
create policy messages_select on messages for select using (
  exists (select 1 from message_threads t where t.id = thread_id and (t.user_id = auth.uid() or is_admin()))
);
drop policy if exists messages_insert on messages;
create policy messages_insert on messages for insert with check (
  sender_id = auth.uid() and
  exists (select 1 from message_threads t where t.id = thread_id and (t.user_id = auth.uid() or is_admin()))
);
drop policy if exists messages_update on messages;
create policy messages_update on messages for update using (
  exists (select 1 from message_threads t where t.id = thread_id and (t.user_id = auth.uid() or is_admin()))
);

-- leads / calls / appointments / reports / qualified_leads: creator + admin
drop policy if exists leads_all on leads;
create policy leads_all on leads for all using (created_by = auth.uid() or is_admin()) with check (created_by = auth.uid() or is_admin());

drop policy if exists calls_all on calls;
create policy calls_all on calls for all using (created_by = auth.uid() or is_admin()) with check (created_by = auth.uid() or is_admin());

drop policy if exists appointments_all on appointments;
create policy appointments_all on appointments for all using (created_by = auth.uid() or is_admin()) with check (created_by = auth.uid() or is_admin());

drop policy if exists reports_all on reports;
create policy reports_all on reports for all using (created_by = auth.uid() or is_admin()) with check (created_by = auth.uid() or is_admin());

drop policy if exists qualified_leads_all on qualified_leads;
create policy qualified_leads_all on qualified_leads for all using (created_by = auth.uid() or is_admin()) with check (created_by = auth.uid() or is_admin());

-- tasks: assignee can read/update their own; admin full access
drop policy if exists tasks_select on tasks;
create policy tasks_select on tasks for select using (assigned_to = auth.uid() or is_admin());
drop policy if exists tasks_insert on tasks;
create policy tasks_insert on tasks for insert with check (is_admin());
drop policy if exists tasks_update on tasks;
create policy tasks_update on tasks for update using (assigned_to = auth.uid() or is_admin());

-- notifications: recipient only (admin is normally the recipient)
drop policy if exists notifications_select on notifications;
create policy notifications_select on notifications for select using (recipient_id = auth.uid());
drop policy if exists notifications_insert on notifications;
create policy notifications_insert on notifications for insert with check (true);
drop policy if exists notifications_update on notifications;
create policy notifications_update on notifications for update using (recipient_id = auth.uid());

-- ------------------------------------------------------------
-- Realtime: add tables to the realtime publication
-- ------------------------------------------------------------
alter publication supabase_realtime add table messages;
alter publication supabase_realtime add table leads;
alter publication supabase_realtime add table calls;
alter publication supabase_realtime add table appointments;
alter publication supabase_realtime add table reports;
alter publication supabase_realtime add table qualified_leads;
alter publication supabase_realtime add table tasks;
alter publication supabase_realtime add table notifications;
alter publication supabase_realtime add table applications;

-- ------------------------------------------------------------
-- Notification helper trigger: fire a notification to every approved
-- admin whenever certain tables get a new row.
-- ------------------------------------------------------------
create or replace function notify_admins(p_type text, p_body text) returns void as $$
begin
  insert into notifications (recipient_id, type, body)
  select id, p_type, p_body from profiles where role = 'admin' and status = 'approved';
end;
$$ language plpgsql security definer;

create or replace function trg_notify_new_lead() returns trigger as $$
begin
  perform notify_admins('new_lead', 'New lead submitted: ' || new.business_name);
  return new;
end;
$$ language plpgsql security definer;
drop trigger if exists on_lead_insert on leads;
create trigger on_lead_insert after insert on leads for each row execute function trg_notify_new_lead();

create or replace function trg_notify_new_qualified_lead() returns trigger as $$
begin
  perform notify_admins('qualified_lead', 'New qualified lead: ' || new.business_name);
  return new;
end;
$$ language plpgsql security definer;
drop trigger if exists on_qualified_lead_insert on qualified_leads;
create trigger on_qualified_lead_insert after insert on qualified_leads for each row execute function trg_notify_new_qualified_lead();

create or replace function trg_notify_new_report() returns trigger as $$
begin
  perform notify_admins('new_report', 'New activity report submitted');
  return new;
end;
$$ language plpgsql security definer;
drop trigger if exists on_report_insert on reports;
create trigger on_report_insert after insert on reports for each row execute function trg_notify_new_report();

create or replace function trg_notify_new_call() returns trigger as $$
begin
  perform notify_admins('new_call', 'New call logged: ' || new.business_name);
  return new;
end;
$$ language plpgsql security definer;
drop trigger if exists on_call_insert on calls;
create trigger on_call_insert after insert on calls for each row execute function trg_notify_new_call();

create or replace function trg_notify_new_appointment() returns trigger as $$
begin
  perform notify_admins('new_appointment', 'New appointment: ' || new.business_name);
  return new;
end;
$$ language plpgsql security definer;
drop trigger if exists on_appointment_insert on appointments;
create trigger on_appointment_insert after insert on appointments for each row execute function trg_notify_new_appointment();

create or replace function trg_notify_new_application() returns trigger as $$
begin
  perform notify_admins('new_application', 'New account application: ' || new.full_name);
  return new;
end;
$$ language plpgsql security definer;
drop trigger if exists on_application_insert on applications;
create trigger on_application_insert after insert on applications for each row execute function trg_notify_new_application();

create or replace function trg_notify_new_message() returns trigger as $$
declare
  v_sender_role text;
  v_thread_owner uuid;
begin
  if new.sender_role <> 'admin' then
    perform notify_admins('new_message', 'New message received');
  else
    select user_id into v_thread_owner from message_threads where id = new.thread_id;
    insert into notifications (recipient_id, type, body)
    values (v_thread_owner, 'admin_reply', 'Admin replied to your message');
  end if;
  return new;
end;
$$ language plpgsql security definer;
drop trigger if exists on_message_insert on messages;
create trigger on_message_insert after insert on messages for each row execute function trg_notify_new_message();
