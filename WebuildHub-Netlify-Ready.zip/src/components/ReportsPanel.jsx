import { useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from '../lib/AuthContext';
import { useRealtimeTable } from '../lib/useRealtimeTable';
import { useSaveStatus } from '../lib/useSaveStatus';
import SaveStatus from './SaveStatus';

const empty = {
  report_date: new Date().toISOString().slice(0, 10),
  calls_made: 0, businesses_contacted: 0, leads_generated: 0,
  follow_ups: 0, meetings: 0, general_notes: '',
};

export default function ReportsPanel({ showAll = false, salesRepNames = {} }) {
  const { session, profile } = useAuth();
  const { rows, loading } = useRealtimeTable('reports');
  const [form, setForm] = useState(empty);
  const { status, errorMessage, run } = useSaveStatus();
  const canCreate = profile?.role === 'sales_rep';

  const num = (v) => (v === '' ? 0 : Number(v));

  const submit = async (e) => {
    e.preventDefault();
    const ok = await run(() =>
      supabase.from('reports').insert({ ...form, created_by: session.user.id })
    );
    if (ok) setForm(empty);
  };

  return (
    <div className="panel">
      {canCreate && (
        <form onSubmit={submit} className="record-form">
          <h3>Submit Report</h3>
          <div className="grid-2">
            <label>Date<input type="date" value={form.report_date} onChange={(e) => setForm({ ...form, report_date: e.target.value })} /></label>
            <label>Calls made<input type="number" min="0" value={form.calls_made} onChange={(e) => setForm({ ...form, calls_made: num(e.target.value) })} /></label>
            <label>Businesses contacted<input type="number" min="0" value={form.businesses_contacted} onChange={(e) => setForm({ ...form, businesses_contacted: num(e.target.value) })} /></label>
            <label>Leads generated<input type="number" min="0" value={form.leads_generated} onChange={(e) => setForm({ ...form, leads_generated: num(e.target.value) })} /></label>
            <label>Follow-ups<input type="number" min="0" value={form.follow_ups} onChange={(e) => setForm({ ...form, follow_ups: num(e.target.value) })} /></label>
            <label>Meetings<input type="number" min="0" value={form.meetings} onChange={(e) => setForm({ ...form, meetings: num(e.target.value) })} /></label>
          </div>
          <label>General notes<textarea value={form.general_notes} onChange={(e) => setForm({ ...form, general_notes: e.target.value })} /></label>
          <div className="form-actions">
            <button type="submit" disabled={status === 'saving'}>Submit Report</button>
            <SaveStatus status={status} errorMessage={errorMessage} />
          </div>
        </form>
      )}
      <h3>{showAll ? 'All Reports' : 'My Reports'}</h3>
      {loading ? <p className="muted">Loading…</p> : rows.length === 0 ? <p className="muted">No reports submitted yet.</p> : (
        <table className="data-table">
          <thead><tr><th>Date</th><th>Calls</th><th>Contacted</th><th>Leads</th><th>Meetings</th>{showAll && <th>Sales Rep</th>}<th>Submitted</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.report_date}</td><td>{r.calls_made}</td><td>{r.businesses_contacted}</td>
                <td>{r.leads_generated}</td><td>{r.meetings}</td>
                {showAll && <td>{salesRepNames[r.created_by] || '—'}</td>}
                <td>{new Date(r.created_at).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
