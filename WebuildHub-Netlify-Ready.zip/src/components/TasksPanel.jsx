import { useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from '../lib/AuthContext';
import { useRealtimeTable } from '../lib/useRealtimeTable';
import { useSaveStatus } from '../lib/useSaveStatus';
import SaveStatus from './SaveStatus';

export default function TasksPanel({ isAdmin = false, assignableUsers = [] }) {
  const { session } = useAuth();
  const { rows, loading } = useRealtimeTable('tasks');
  const [form, setForm] = useState({ title: '', description: '', assigned_to: '', due_date: '' });
  const { status, errorMessage, run } = useSaveStatus();

  const submit = async (e) => {
    e.preventDefault();
    if (!form.assigned_to) return;
    const ok = await run(() =>
      supabase.from('tasks').insert({ ...form, assigned_by: session.user.id })
    );
    if (ok) setForm({ title: '', description: '', assigned_to: '', due_date: '' });
  };

  const updateStatus = async (id, newStatus) => {
    await supabase.from('tasks').update({ status: newStatus }).eq('id', id);
  };

  return (
    <div className="panel">
      {isAdmin && (
        <form onSubmit={submit} className="record-form">
          <h3>Assign Task</h3>
          <div className="grid-2">
            <label>Title<input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></label>
            <label>Assign to
              <select required value={form.assigned_to} onChange={(e) => setForm({ ...form, assigned_to: e.target.value })}>
                <option value="">Select person…</option>
                {assignableUsers.map((u) => <option key={u.id} value={u.id}>{u.full_name} ({u.role})</option>)}
              </select>
            </label>
            <label>Due date<input type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} /></label>
          </div>
          <label>Description<textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></label>
          <div className="form-actions">
            <button type="submit" disabled={status === 'saving'}>Assign Task</button>
            <SaveStatus status={status} errorMessage={errorMessage} />
          </div>
        </form>
      )}
      <h3>{isAdmin ? 'All Tasks' : 'My Tasks'}</h3>
      {loading ? <p className="muted">Loading…</p> : rows.length === 0 ? <p className="muted">No tasks yet.</p> : (
        <table className="data-table">
          <thead><tr><th>Title</th><th>Due</th><th>Status</th>{!isAdmin && <th></th>}</tr></thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.id}>
                <td>{t.title}<div className="muted small">{t.description}</div></td>
                <td>{t.due_date || '—'}</td>
                <td><span className={`badge status-${t.status}`}>{t.status.replace('_', ' ')}</span></td>
                {!isAdmin && (
                  <td>
                    {t.status !== 'done' && (
                      <select value={t.status} onChange={(e) => updateStatus(t.id, e.target.value)}>
                        <option value="open">Open</option>
                        <option value="in_progress">In progress</option>
                        <option value="done">Done</option>
                      </select>
                    )}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
