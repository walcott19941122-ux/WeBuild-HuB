import { supabase } from '../lib/supabaseClient';
import { useRealtimeTable } from '../lib/useRealtimeTable';

export default function NotificationsPanel() {
  const { rows, loading } = useRealtimeTable('notifications');
  const unread = rows.filter((r) => !r.read_at);

  const markRead = async (id) => {
    await supabase.from('notifications').update({ read_at: new Date().toISOString() }).eq('id', id);
  };

  const markAllRead = async () => {
    const ids = unread.map((r) => r.id);
    if (ids.length) await supabase.from('notifications').update({ read_at: new Date().toISOString() }).in('id', ids);
  };

  return (
    <div className="panel">
      <div className="panel-header">
        <h3>Notifications {unread.length > 0 && <span className="unread-count">{unread.length}</span>}</h3>
        {unread.length > 0 && <button className="link-btn" onClick={markAllRead}>Mark all read</button>}
      </div>
      {loading ? <p className="muted">Loading…</p> : rows.length === 0 ? <p className="muted">No notifications yet.</p> : (
        <ul className="notif-list">
          {rows.map((n) => (
            <li key={n.id} className={n.read_at ? 'read' : 'unread'} onClick={() => !n.read_at && markRead(n.id)}>
              <span>{n.body}</span>
              <span className="notif-time">{new Date(n.created_at).toLocaleString()}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
