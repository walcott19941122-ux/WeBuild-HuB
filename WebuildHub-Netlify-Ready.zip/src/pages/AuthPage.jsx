import { useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useSaveStatus } from '../lib/useSaveStatus';
import SaveStatus from '../components/SaveStatus';

export default function AuthPage() {
  const [mode, setMode] = useState('login'); // login | signup
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState('worker');
  const [phone, setPhone] = useState('');
  const [formError, setFormError] = useState('');
  const { status, errorMessage, run } = useSaveStatus();

  const handleLogin = async (e) => {
    e.preventDefault();
    setFormError('');
    const ok = await run(() => supabase.auth.signInWithPassword({ email, password }));
    if (!ok) return;
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setFormError('');
    if (role === 'admin') {
      setFormError('Admin accounts are created directly in Supabase, not through signup.');
      return;
    }
    const ok = await run(async () => {
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({ email, password });
      if (signUpError) return { error: signUpError };

      const userId = signUpData.user?.id;
      if (!userId) return { error: { message: 'No user returned from sign up' } };

      const { error: profileError } = await supabase.from('profiles').insert({
        id: userId,
        full_name: fullName,
        role,
        status: 'pending',
        phone,
      });
      if (profileError) return { error: profileError };

      const { error: appError } = await supabase.from('applications').insert({
        user_id: userId,
        full_name: fullName,
        requested_role: role,
        phone,
        status: 'pending',
      });
      return { error: appError };
    });
    if (ok) {
      setFormError('Application submitted. An admin needs to approve your account before you can log in.');
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>weBUILD Business Hub</h1>
        <div className="auth-tabs">
          <button className={mode === 'login' ? 'active' : ''} onClick={() => setMode('login')}>Log in</button>
          <button className={mode === 'signup' ? 'active' : ''} onClick={() => setMode('signup')}>Apply for account</button>
        </div>

        {mode === 'login' ? (
          <form onSubmit={handleLogin}>
            <label>Email
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </label>
            <label>Password
              <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
            </label>
            <button type="submit" disabled={status === 'saving'}>Log in</button>
            <SaveStatus status={status} errorMessage={errorMessage} />
          </form>
        ) : (
          <form onSubmit={handleSignup}>
            <label>Full name
              <input required value={fullName} onChange={(e) => setFullName(e.target.value)} />
            </label>
            <label>Email
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </label>
            <label>Password
              <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
            </label>
            <label>Phone
              <input value={phone} onChange={(e) => setPhone(e.target.value)} />
            </label>
            <label>Role
              <select value={role} onChange={(e) => setRole(e.target.value)}>
                <option value="worker">Worker</option>
                <option value="sales_rep">Sales Representative</option>
              </select>
            </label>
            <button type="submit" disabled={status === 'saving'}>Submit application</button>
            <SaveStatus status={status} errorMessage={errorMessage} />
          </form>
        )}
        {formError && <p className="form-note">{formError}</p>}
      </div>
    </div>
  );
}
