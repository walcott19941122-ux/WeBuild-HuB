import { useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from '../lib/AuthContext';
import { useRealtimeTable } from '../lib/useRealtimeTable';
import { useSaveStatus } from '../lib/useSaveStatus';
import SaveStatus from './SaveStatus';

const empty = { business_name: '', country: '', service: '' };

export default function QualifiedLeadsPanel({ isAdmin = false, salesRepNames = {} }) {
  const { session, profile } = useAuth();
  const { rows, loading } = useRealtimeTable('qualified_leads');
  const [form, setForm] = useState(empty);
  const { status, errorMessage, run } = useSaveStatus();
  const [updatingId, setUpdatingId] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    const ok = await run(() =>
      supabase.from('qualified_leads').insert({ ...form, created_by: session.user.id })
    );
    if (ok) setForm(empty);
  };

  const markHandled = async (id) => {
    setUpdatingId(id);
    await supabase.from('qualified_leads').update({ status: 'handled' }).eq('id', id);
    setUpdatingId(null);
  };

  return (
    <div className="panel">
      {profile?.role === 'sales_rep' && (
        <form onSubmit={submit} className="record-form">
          <h3>Send Qualified Lead</h3>
          <div className="grid-2">
            <label>Business<input required value={form.business_name} onChange={(e) => setForm({ ...form, business_name: e.target.value })} /></label>
            <label>Country<input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></label>
            <label>Service<input value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })} /></label>
          </div>
          <div className="form-actions">
            <button type="submit" disabled={status === 'saving'}>Send to weBUILD</button>
            <SaveStatus status={status} errorMessage={errorMessage} />
          </div>
        </form>
      )}
      <h3>Qualified Leads</h3>
      {loading ? <p className="muted">Loading…</p> : rows.length === 0 ? <p className="muted">None yet.</p> : (
        <table className="data-table">
          <thead><tr><th>Business</th><th>Country</th><th>Service</th><th>Sales Rep</th><th>Sent</th><th>Status</th>{isAdmin && <th></th>}</tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.business_name}</td><td>{r.country}</td><td>{r.service}</td>
                <td>{salesRepNames[r.created_by] || '—'}</td>
                <td>{new Date(r.created_at).toLocaleString()}</td>
                <td><span className={`badge status-${r.status}`}>{r.status}</span></td>
                {isAdmin && (
                  <td>
                    {r.status === 'unhandled' && (
                      <button className="link-btn" disabled={updatingId === r.id} onClick={() => markHandled(r.id)}>
                        Mark Handled
                      </button>
                    )}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
